// Browser client. Only the anon key is ever present here (TRD-4.3).
"use client";
import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "@/lib/db/types";

export function createSupabaseBrowserClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL ?? "",
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "",
  );
}
